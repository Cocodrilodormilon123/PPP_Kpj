package crip.persona.com.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonaMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
