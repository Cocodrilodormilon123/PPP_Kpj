package crip.oferta.com.pe.Entities;

public enum EstadoOferta {
    ACTIVA,
    INACTIVA,
    CERRADA,
    FINALIZADA
}