package crip.persona.com.pe.Entities;

public enum TipoPersona {
    ESTUDIANTE,
    ADMIN
}
