package crip.practica.com.pe.Entities;

public enum EstadoPractica {
    EN_PROCESO,
    FINALIZADA
}