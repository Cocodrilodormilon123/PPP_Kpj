package crip.oferta.com.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfertaMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
