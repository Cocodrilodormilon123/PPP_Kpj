package crip.oferta.com.pe.models;

public enum TipoPersona {
    ESTUDIANTE,
    ADMIN
}