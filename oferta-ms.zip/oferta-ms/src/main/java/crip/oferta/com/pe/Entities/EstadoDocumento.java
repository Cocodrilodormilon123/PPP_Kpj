package crip.oferta.com.pe.Entities;

public enum EstadoDocumento {
    PENDIENTE,
    ACEPTADO,
    RECHAZADO
}
