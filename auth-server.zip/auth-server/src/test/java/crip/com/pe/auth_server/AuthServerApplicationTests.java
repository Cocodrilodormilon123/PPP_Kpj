package crip.com.pe.auth_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
