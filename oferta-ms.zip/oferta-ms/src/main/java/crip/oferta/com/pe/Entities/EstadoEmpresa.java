package crip.oferta.com.pe.Entities;

public enum EstadoEmpresa {
    ACTIVA,
    INACTIVA,
    SUSPENDIDA
}