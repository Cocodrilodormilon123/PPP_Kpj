package crip.oferta.com.pe.Entities;

public enum ModalidadOferta {
    PRESENCIAL,
    VIRTUAL,
    SEMI_PRESENCIAL
}
