package crip.practica.com.pe.Entities;

public enum EstadoEvidencia {
    PENDIENTE,
    ACEPTADA,
    RECHAZADA
}