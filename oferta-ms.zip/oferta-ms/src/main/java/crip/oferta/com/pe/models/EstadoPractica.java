package crip.oferta.com.pe.models;

public enum EstadoPractica {
    EN_PROCESO,
    FINALIZADA
}