package crip.oferta.com.pe.Entities;

public enum EstadoPostulacion {
    PENDIENTE,
    EN_REVISION,
    RECHAZADA
}