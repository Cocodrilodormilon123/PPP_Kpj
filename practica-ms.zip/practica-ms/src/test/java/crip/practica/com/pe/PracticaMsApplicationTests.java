package crip.practica.com.pe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
